<?php
require('../controlador/controlador.php');
controlarVistas();

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
include_once("../modelo/evento.php");
$evento = new Evento();

if (isset($_GET['id_perfil'])) {
    $id_perfil = $_GET['id_perfil'];
    $consulta = $evento->mostrarResena($id_perfil);
}

$imagenEvento = "img/favicon.png";

$datosPerfil = $persona->mostrarPerfil($_GET["id_perfil"]);
?>

<main id="main">
    <?php if (isset($_GET["id_perfil"]) and !empty($_GET["id_perfil"]) and $consulta) : ?>
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Reseñas</h1>
                        <span class="color-text-a">Reseñas de usuario</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Reseñas de usuario
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->
    
    <!-- ======= Sección del perfil de usuario ======= -->
    <section class="agent-single">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row">

                        <!--/ Imagen de perfil /-->
                        <div class="col-md-6">
                            <div class="agent-avatar-box">
                                <img src="../assets/<?php echo $imagenEvento; ?>" alt="Imagen del evento" width="450" class="agent-avatar img-fluid">
                            </div>
                        </div>

                        <!--/ Datos de usuario /-->
                        <div class="col-md-5 section-md-t3">
                            <div class="agent-info-box">
                                <!--/ Nombre de usuario /-->
                                <div class="agent-title">
                                    <div class="title-box-d">
                                        <h3 class="title-d">
                                            Reseñas de <br/>
                                            <?php echo $datosPerfil["NOMBRE"]." ".$datosPerfil["APELLIDOS"]; ?>:
                                        </h3>
                                    </div>
                                </div>
                                <!--/ Descripcción y datos de usuario /-->
                                <?php
                                foreach ($consulta as $registro) {
                                ?>
                                <h4>
                                    <strong>Evento: </strong><span class="color-text-a"><?php echo $registro['nombre_evento']; ?></span>
                                </h4>
                                    <div class="agent-content mb-3">
                                        <p class="content-d color-text-a">
                                        <p><strong>Comentario:</strong></p>
                                        <?php echo $registro['COMENTARIO']; ?>
                                        </p>
                                        <div class="info-agents color-a">
                                            <p><strong>Puntuación: </strong><span class="color-text-a"></span>
                                                <?php for ($i = 0; $i < $registro['PUNTUACION']; $i++) { ?>
                                                    <i class="bi bi-star-fill text-warning"></i>
                                                <?php } ?>
                                            </p>                                         
                                            <p><strong>Suscriptor: </strong><span class="color-text-a"><?php echo $registro['subscriptor']; ?></span></p>
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/ FIN Sección del perfil de usuario /-->

    <?php else : // Si no se encuentra el usuario ?>
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">¿Y las reseñas?</h1>
              <span class="color-text-a">¡Parece que ha habido un error!<br />Inténtalo de nuevo más tarde<br /></span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="inicio.php">Inicio</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    Reseñas de usuario
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- FIN Título/Breadcrumbs -->
    <?php endif; ?>
</main>

<?php include('modulos_compartidos/footer.php'); ?>