<!-- ======= Cuadrícula Eventos ======= -->
<section class="property-grid grid">
    <div class="container">
        <div class="row">
            <form action="" method="post" enctype="multipart/form-data">
                <!--/ Nombre evento /-->
                <div class="form-group mt-4">
                    <label for="nombre">*Nombre del Evento</label>
                    <input class="form-control" type="text" name="nombre" placeholder="Nombre" value="<?php echo $vista_ACTUAL == "editar_evento.php" ? $consulta['NOMBRE'] : '' ; ?>" required>
                </div>

                <!--/ Descripción evento /-->
                <div class="form-group mt-4">
                    <label for="descripcion">*Descripción del evento</label><br>
                    <input class="form-control" type="text" name="descripcion" placeholder="Descripcion" value="<?php echo $vista_ACTUAL == "editar_evento.php" ? $consulta['DESCRIPCION'] : '' ; ?>" required>
                </div>

                <!--/ Aforo evento /-->
                <div class="form-group mt-4">
                    <label for="aforo">*Aforo</label>
                    <input class="form-control" type="number" name="aforo" placeholder="Número de personas" value="<?php echo $vista_ACTUAL == "editar_evento.php" ? $consulta['AFORO'] : '' ; ?>" required>
                </div>

                <!--/ Fecha evento /-->
                <div class="form-group mt-4">
                    <label for="fecha">*Fecha del evento</label>
                    <input class="form-control" type="date" name="fecha" placeholder="fecha" min="<?php echo date('Y-m-d'); ?>" value="<?php echo $vista_ACTUAL == "editar_evento.php" ? $consulta['FECHA_HORA'] : '' ; ?>" required>
                </div>

                <!--/ Categoría evento /-->
                <div class="form-group mt-4">
                    <label for="categoria">*Categoría del evento</label>
                    <select class="form-control" name="categoria" id="categoria" required>
                        <option value="Excursion" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['CATEGORIA'] == 'EXCURSION') ? 'selected' : '' ; ?>>Excursión</option>
                        <option value="Fiesta" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['CATEGORIA'] == 'FIESTA') ? 'selected' : '' ; ?>>Fiesta</option>
                        <option value="Viajes" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['CATEGORIA'] == 'VIAJES') ? 'selected' : '' ; ?>>Viajes</option>
                        <option value="Musica" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['CATEGORIA'] == 'MUSICA') ? 'selected' : '' ; ?>>Música</option>
                        <option value="Deportes" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['CATEGORIA'] == 'DEPORTES') ? 'selected' : '' ; ?>>Deportes</option>
                    </select>
                </div>

                <!--/ Provincia evento /-->
                <div class="form-group mt-4">
                    <label for="provincia">*Provincia del evento</label><br>
                    <select class="form-control" name="provincia">
                        <option value="1" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['PROVINCIA'] == 1) ? 'selected' : '' ; ?>>Madrid</option>
                        <option value="2" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['PROVINCIA'] == 2) ? 'selected' : '' ; ?>>Barcelona</option>
                        <option value="3" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['PROVINCIA'] == 3) ? 'selected' : '' ; ?>>Sevilla</option>
                        <option value="4" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['PROVINCIA'] == 4) ? 'selected' : '' ; ?>>Asturias</option>
                        <option value="5" <?php echo ($vista_ACTUAL == "editar_evento.php" && $consulta['PROVINCIA'] == 5) ? 'selected' : '' ; ?>>Zaragoza</option>
                    </select>
                </div>

                <!--/ Foto evento /-->
                <div class="form-group mt-4">
                    <label for="foto">Subir foto del evento</label>
                    <input class="form-control" type="file" name="foto[]" accept="image/*">
                </div>
                <br />

                <!--/ Opciones de formulario /-->
                <?php if ($vista_ACTUAL == "crear_evento.php") : // Si la vista es crear evento  ?>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-b" name="crear_evento">Crear evento</button>
                </div>
                <?php elseif ($vista_ACTUAL == "editar_evento.php") : // Si la vista es editar evento ?>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-b" name="editar_evento"><i class="bi bi-calendar2-check"></i> Confirmar cambios</button>
                    <button type="submit" class="btn btn-b" style="background-color: salmon;" name="borrar_evento"><i class="bi bi-calendar-x"></i> Borrar evento</button>
                </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</section>