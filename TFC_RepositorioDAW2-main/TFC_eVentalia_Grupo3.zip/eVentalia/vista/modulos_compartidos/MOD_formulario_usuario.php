<section class="property-grid grid">
    <div class="container">
        <div class="row">
            <form action="" method="post" enctype="multipart/form-data">
                <!--/ Nombre usuario /-->
                <div class="form-group mt-4">
                    <label for="nombre">*Nombre</label>
                    <input class="form-control" type="text" name="nombre" maxlength="15" placeholder="Nombre" value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta['NOMBRE'] : ""; ?>" required>
                </div>

                <!--/ Apellidos usuario /-->
                <div class="form-group mt-4">
                    <label for="apellidos">*Apellidos</label>
                    <input class="form-control" type="text" name="apellidos" maxlength="50" placeholder="Apellidos" value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta['APELLIDOS'] : ""; ?>" required>
                </div>

                <!--/ Descripción /-->
                <div class="form-group mt-4">
                    <label for="apellidos">Descripción</label>
                    <input class="form-control" type="text" name="descripcion" maxlength="100" placeholder="Acerca de ti..." value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta['DESCRIPCION'] : ""; ?>">
                </div>

                <!--/ Email usuario /-->
                <div class="form-group mt-4">
                    <label for="email">*Email</label>
                    <input class="form-control" type="email" name="email" maxlength="255" placeholder="Correo electrónico" value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta['EMAIL'] : ""; ?>" <?php echo $vista_ACTUAL == "registro.php" ? "required" : ($vista_ACTUAL == "editar_usuario.php" ? "disabled" : ""); ?>>
                </div>

                <!--/ Password usuario /-->
                <div class="form-group mt-4">
                    <label for="pass_1"><?php echo $vista_ACTUAL == "registro.php" ? "*Contraseña" : ($vista_ACTUAL == "editar_usuario.php" ? "Contraseña actual" : ""); ?></label>
                    <input class="form-control" type="password" name="pass_1" placeholder="Contraseña" <?php echo $vista_ACTUAL == "registro.php" ? "required" : ""; ?>>
                </div>

                <!--/ Confirmación Password usuario /-->
                <div class="form-group mt-4">
                    <label for="pass_2"><?php echo $vista_ACTUAL == "registro.php" ? "*Confirmar contraseña" : ($vista_ACTUAL == "editar_usuario.php" ? "Nueva contraseña" : ""); ?></label>
                    <input class="form-control" type="password" name="pass_2" placeholder="Contraseña" <?php echo $vista_ACTUAL == "registro.php" ? "required" : ""; ?>>
                </div>

                <!--/ Dirección usuario /-->
                <div class="form-group mt-4">
                    <label for="direccion">*Dirección</label>
                    <input class="form-control" type="text" name="direccion" maxlength="50" placeholder="Dirección" value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta["DIRECCION"] : ""; ?>" required>
                </div>

                <!--/ Foto usuario /-->
                <div class="form-group mt-4">
                    <label for="foto">Subir foto para tu perfil de usuario</label>
                    <input class="form-control" type="file" name="foto[]" accept="image/*">
                </div>

                <!--/ Teléfono usuario /-->
                <div class="form-group mt-4">
                    <label for="telefono">*Número de teléfono</label>
                    <input class="form-control" type="text" name="telefono" maxlength="9" placeholder="Número de teléfono" value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta["TELEFONO"] : ""; ?>" required>
                </div>

                <!--/ Nacimiento usuario /-->
                <div class="form-group mt-4">
                    <label for="nacimiento">*Fecha de nacimiento</label>
                    <input class="form-control" type="Date" name="nacimiento" max="<?php echo $fechaMinima; ?>" placeholder="Fecha de nacimiento" value="<?php echo $vista_ACTUAL == "editar_usuario.php" ? $consulta["FECHA_NACIMIENTO"] : ""; ?>" <?php echo $vista_ACTUAL == "registro.php" ? "required" : ($vista_ACTUAL == "editar_usuario.php" ? "disabled" : ""); ?>>
                </div>
                <br />

                <!--/ Botones del formulario /-->
                <?php if ($vista_ACTUAL == "registro.php"): // Si se está registrando una cuenta ?>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-b" name="registrar_usuario">Registrar Cuenta</button>
                </div>
                <?php elseif ($vista_ACTUAL == "editar_usuario.php"): // Si se está editando una cuenta ?>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-b" name="editar_usuario">Confirmar cambios</button>
                    <button type="submit" class="btn btn-b" style="background-color: salmon;" name="borrar_usuario"><i class="bi bi-calendar-x"></i> Eliminar cuenta</button>
                </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</section>