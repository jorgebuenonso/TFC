<?php
/*
  NOTAS:
    - La lógica de esta sección se emplea en los botones de la navegación paginada.
    - Los datos necesarios para la paginación se construyen en la consulta: eventos->buscarEvento();
*/

// Transformar valores de URL en array
$queryString = $_SERVER['QUERY_STRING'];
$queryValues = array();
parse_str($_SERVER['QUERY_STRING'], $queryValues);

$nombre = isset($queryValues["nombre"]) ? $queryValues["nombre"] : "";
$categoria = isset($queryValues["categoria"]) ? $queryValues["categoria"] : "";
$provincia = isset($queryValues["provincia"]) ? $queryValues["provincia"] : "";
$aforo = isset($queryValues["aforo"]) ? $queryValues["aforo"] : "";


// Datos botones paginación
# --------------------------------------------------------------
if (isset($queryValues["pag"]) and !empty($queryValues["pag"]) and $queryValues["pag"] + 1 < $total_pag) {
  $siguiente_pag = $queryValues["pag"] + 1;
  $siguiente_pag = $siguiente_pag > 1 ? $siguiente_pag : 1;
} else {
  $siguiente_pag = $total_pag;
}

if (isset($queryValues["pag"]) and !empty($queryValues["pag"]) and $queryValues["pag"] - 1 > 1) {
  $anterior_pag = $queryValues["pag"] - 1;
  $anterior_pag = $anterior_pag < $total_pag ? $anterior_pag : $total_pag;
} else {
  $anterior_pag = 1;
}

$siguiente_pag = "nombre={$nombre}&categoria={$categoria}&provincia={$provincia}&aforo={$aforo}&pag=" . $siguiente_pag;
$anterior_pag = "nombre={$nombre}&categoria={$categoria}&provincia={$provincia}&aforo={$aforo}&pag=" . $anterior_pag;
$primera_pag = "nombre={$nombre}&categoria={$categoria}&provincia={$provincia}&aforo={$aforo}&pag=1";
$ultima_pag = "nombre={$nombre}&categoria={$categoria}&provincia={$provincia}&aforo={$aforo}&pag=" . $total_pag;
# --------------------------------------------------------------


?>

<!-- ======= Cuadrícula Eventos ======= -->
<section class="property-grid grid">
  <div class="container">
    <div class="row">

      <!--/ Filtros de búsqueda /-->
      <div class="col-sm-12">
        <div class="grid-option">
          <form action="" method="GET">

            <!--/ Nombre evento /-->
            <label class="pb-2" style="font-size: 25px;" for="Type">Nombre</label>
            <input type="text" class="custom-select" style="border: 1px solid; font-size: 25px;" placeholder="Texto" name="nombre" value="<?php echo isset($_GET['nombre']) ? $_GET['nombre'] : ""; ?>">
            <br>

            <!--/ Categoría evento /-->
            <label class="pb-2" for="Type" style="font-size: 25px;">Categoría</label>
            <select class="custom-select" name="categoria" style="font-size: 25px;">
              <option value="">Todas</option>
              <option value="Excursion" <?php echo (isset($_GET['categoria']) and $_GET['categoria'] == 'Excursion') ? "selected" : ""; ?>>Excursión</option>
              <option value="Fiesta" <?php echo (isset($_GET['categoria']) and $_GET['categoria'] == 'Fiesta') ? "selected" : ""; ?>>Fiesta</option>
              <option value="Viajes" <?php echo (isset($_GET['categoria']) and $_GET['categoria'] == 'Viajes') ? "selected" : ""; ?>>Viajes</option>
              <option value="Musica" <?php echo (isset($_GET['categoria']) and $_GET['categoria'] == 'Musica') ? "selected" : ""; ?>>Música</option>
              <option value="Deportes" <?php echo (isset($_GET['categoria']) and $_GET['categoria'] == 'Deportes') ? "selected" : ""; ?>>Deportes</option>
            </select>
            <br>

            <!--/ Provincia evento /-->
            <label class="pb-2" for="Type" style="font-size: 25px;">Provincia</label>
            <select class="custom-select" style="font-size: 25px;" name="provincia">
              <option value="">Todas</option>
              <option value="1" <?php echo (isset($_GET['provincia']) and $_GET['provincia'] == '1') ? "selected" : ""; ?>>Madrid</option>
              <option value="2" <?php echo (isset($_GET['provincia']) and $_GET['provincia'] == '2') ? "selected" : ""; ?>>Barcelona</option>
              <option value="3" <?php echo (isset($_GET['provincia']) and $_GET['provincia'] == '3') ? "selected" : ""; ?>>Sevilla</option>
              <option value="4" <?php echo (isset($_GET['provincia']) and $_GET['provincia'] == '4') ? "selected" : ""; ?>>Asturias</option>
              <option value="5" <?php echo (isset($_GET['provincia']) and $_GET['provincia'] == '5') ? "selected" : ""; ?>>Zaragoza</option>
            </select>
            <br>

            <!--/ Aforo evento /-->
            <label class="pb-2" for="Type" style="font-size: 25px;">Aforo</label>
            <select class="custom-select" style="font-size: 25px;" name="aforo">
              <option value="">Sin límite</option>
              <option value="10" <?php echo (isset($_GET['aforo']) and $_GET['aforo'] == '10') ? "selected" : ""; ?>>Hasta 10</option>
              <option value="50" <?php echo (isset($_GET['aforo']) and $_GET['aforo'] == '50') ? "selected" : ""; ?>>Hasta 50</option>
              <option value="100" <?php echo (isset($_GET['aforo']) and $_GET['aforo'] == '100') ? "selected" : ""; ?>>Hasta 100</option>
            </select>
            <br />

            <!--/ Filtro de tipo /-->
            <?php if ($vista_ACTUAL == "perfil_usuario.php") : ?>
              <label class="pb-2" for="Type" style="font-size: 25px;">Mostrar</label>
              <select class="custom-select" style="font-size: 25px;" name="mostrar">
                <option value="Creados">Creados</option>
                <option value="Subscritos" <?php echo (isset($_GET['mostrar']) and $_GET['mostrar'] == 'Subscritos') ? "selected" : ""; ?>>Subscritos</option>
              </select>
              <br />
            <?php endif; ?>

            <!--/ Botón de búsqueda /-->
            <div class="col-md-12">
              <button type="submit" class="btn btn-b"><i class="bi bi-search"></i> Buscar evento</button>
            </div>

            <!--/ Paginación /-->
            <br />
            <div class="row">
              <div class="col-sm-12">
                <nav class="pagination-a">
                  <ul class="pagination justify-content-end">

                    <!--/ Anterior página /-->
                    <li class="page-item ">
                      <a class="page-link" href="<?php echo $vista_ACTUAL . '?' . $anterior_pag ?>">
                        <span class="bi bi-chevron-left"></span>
                      </a>
                    </li>

                    <!--/ Primera página /-->
                    <li class="page-item">
                      <a class="page-link" href="<?php echo $vista_ACTUAL . '?' . $primera_pag; ?>">1</a>
                    </li>

                    <!--/ Página actual y buscador /-->
                    <input type="number" class="custom-select" style="border: 1px solid; width: 4rem; text-align: center;" name="pag" placeholder="pag..." value="<?php echo $pag_actual ?>">

                    <!--/ Última página /-->
                    <li class="page-item">
                      <a class="page-link" href="<?php echo $vista_ACTUAL . '?' . $ultima_pag; ?>"><?php echo $total_pag ?></a>
                    </li>

                    <!--/ Siguiente página /-->
                    <li class="page-item">
                      <a class="page-link" href="<?php echo $vista_ACTUAL . '?' . $siguiente_pag ?>">
                        <span class="bi bi-chevron-right"></span>
                      </a>
                    </li>

                  </ul>
                </nav>
              </div>
            </div>
          </form>
        </div>
      </div><!--/ FIN Filtros de búsqueda /-->

      <!--/ Lista de eventos /-->
      <?php
      $fechaHoy = new DateTime();
      $fechaAyer = clone $fechaHoy;
      $fechaAyer->modify('-1 day');
      // $fechaAyer = clone $fechaHoy->modify('-1 day');
      // $fechaHoy->modify('+1 day');


      foreach ($consulta as $key => $fila) :
        // Comprobar si la subscripción sigue abierta (habilitado hasta el mismo día del evento)
        $fechaEvento = new DateTime($fila["FECHA_HORA"]);
        $eventoCerrado = $fechaEvento <= $fechaAyer ? true : false;

        // Formatear fecha
        $fechaFormateada = strtotime($fila['FECHA_HORA']);
        $fechaFormateada = date('d/m/Y', $fechaFormateada);

        // Calcular rangos de fecha
        $fechaLimiteResena = $evento->fechaLimiteResena($fila['FECHA_HORA']);
        $eventoExpirado = $evento->eventoExpirado($fila['FECHA_HORA']);

        // Comprobar subscripción de usuario
        $usuarioSubscrito = $evento->comporobarSubscripcion($fila["ID_EVENTO"], $datosUsuario["ID_PERSONA"]);

        // Comprobar si el usuario ha escrito una reseña
        $verificarResena = $evento->verificarFechaResena($fila['FECHA_HORA'], $fila['ID_EVENTO'], $datosUsuario["ID_PERSONA"]);

        // Si no hay imagen, reemplazar por defecto
        $imagenEvento = isset($fila['IMAGEN_EVENTO']) ? "fotos_eventos/" . $fila['IMAGEN_EVENTO'] : "img/favicon.png";
      ?>
        <div class="col-md-4">
          <div class="card-box-a card-shadow">
            <div class="img-box-a">
              <div class="image-container">
              <img src="../assets/<?php echo $imagenEvento; ?>" alt="" class="img-a img-fluid" style="min-height: 500px; max-width: 500px; height: auto;">
              </div>
            </div>
            <div class="card-overlay">
              <div class="card-overlay-a-content">

                <!--/ Iconos a mostrar al creador /-->
                <?php if ($fila["ID_CREADOR"] == $datosUsuario["ID_PERSONA"]) : ?>
                  <!--/ Icono propietario /-->
                  <div class="card-header-a">
                    <h2 class="card-title-a">
                      <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>" title="Eres el creador"><i class="bi bi-award-fill"></i></a>
                    </h2>
                  </div>

                  <!--/ Icono evento cerrado /-->
                  <?php if ($eventoExpirado) : ?>
                    <div class="card-header-a">
                      <h2 class="card-title-a">
                        <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>" title="Evento caducado"><i class="bi bi-x-circle-fill"></i></a>
                      </h2>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>

                <!--/ Icono de subscripción /-->
                <?php if ($usuarioSubscrito) : ?>
                  <div class="card-header-a">
                    <h2 class="card-title-a">
                      <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>" title="Estás subscrito"><i class="bi bi-emoji-laughing-fill"></i></a>
                    </h2>
                  </div>
                <?php endif; ?>

                <!--/ Icono reseñas abiertas /-->
                <?php if ($fechaLimiteResena) : ?>
                  <div class="card-header-a">
                    <h2 class="card-title-a">
                      <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>" title="Reseñas abiertas"><i class="bi bi-chat-text-fill"></i></a>
                    </h2>
                  </div>
                <?php endif; ?>

                <!--/ Icono de aforo completo del evento o fuera de fecha /-->
                <?php if ($fila["SUBSCRITOS"] >= $fila["AFORO"] or $fechaEvento < $fechaHoy) : ?>
                  <div class="card-header-a">
                    <h2 class="card-title-a">
                      <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>" title="Aforo completo / No disponible"><i class="bi bi-person-fill-slash"></i></a>
                    </h2>
                  </div>
                <?php endif; ?>

                <!--/ Nombre del evento /-->
                <div class="card-header-a">
                  <h2 class="card-title-a">
                    <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>"><?php echo $fila['NOMBRE']; ?></a>
                  </h2>
                </div>

                <!--/ Lugar del evento /-->
                <div class="card-body-a">
                  <div class="price-box d-flex">
                    <span class="price-a"><?php echo $fila['NOMBRE_PROVINCIA'] ?></span>
                  </div>
                  <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO'] ?>" class="link-a">Haz click para ver
                    <span class="bi bi-chevron-right"></span>
                  </a>

                  <!--/ Escribir reseña de evento /-->
                  <?php if (!$verificarResena && $fila['ID_CREADOR'] != $datosUsuario["ID_PERSONA"] and $eventoCerrado) : ?>
                    <a href="crear_resena.php?id_evento=<?php echo $fila['ID_EVENTO']; ?>" class="link-a">Deja una reseña</a>
                    <span class="bi bi-chevron-right"></span>
                  <?php endif; ?>
                </div>

                <!--/ Info del evento /-->
                <div class="card-footer-a">
                  <ul class="card-info d-flex justify-content-around">
                    <li>
                      <h4 class="card-info-title">Categoría</h4>
                      <span><?php echo $fila['CATEGORIA']; ?></span>
                    </li>
                    <li>
                      <h4 class="card-info-title">Fecha</h4>
                      <span><?php echo $fechaFormateada; ?></span>
                    </li>
                    <li>
                      <h4 class="card-info-title">Aforo</h4>
                      <span><?php echo $fila['AFORO'] ?></span>
                    </li>
                  </ul>
                </div>

              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?><!--/ FIN Impresión de eventos /-->

    </div>
</section><!-- FIN Cuadrícula Eventos -->