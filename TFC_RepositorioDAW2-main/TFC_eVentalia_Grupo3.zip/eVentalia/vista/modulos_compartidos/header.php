<!--
  NOTAS:
    - En este documento se incluye el contenido del encabezado.
    - El contenido del encabezado es fluido y permite ampliaciones.
    - La función "basename($_SERVER['PHP_SELF'])" obtiene el nombre del documento actual.
-->

<?php
$vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa

$vistas_EVENTOS = array("ver_eventos.php", "crear_evento.php", "borrar_evento.php", "editar_evento.php", "pagina_evento.php", "crear_resena.php", "listar_resenas.php");
$vistas_SESIONES = array("login.php", "registro.php");
$vistas_PERFILES = array("perfil_usuario.php", "editar_usuario.php");

// En caso de que la vista actual pertenezca al menú de eventos
foreach ($vistas_EVENTOS as $actual) {
  if ($vista_ACTUAL == $actual) {
    $vista_ACTUAL = "menuEventos";
    break;
  }
}

// En caso de que la vista actual pertenezca al menú de sesión
foreach ($vistas_SESIONES as $actual) {
  if ($vista_ACTUAL == $actual) {
    $vista_ACTUAL = "menuSesiones";
    break;
  }
}

// En caso de que la vista actual pertenezca al menú de perfiles
foreach ($vistas_PERFILES as $actual) {
  if ($vista_ACTUAL == $actual) {
    $vista_ACTUAL = "menuPerfiles";
    break;
  }
}
?>

<!-- ======= Header/Navbar ======= -->
<nav class="navbar navbar-default navbar-trans navbar-expand-lg fixed-top">
  <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <a class="navbar-brand text-brand" href="#"><span class="color-b">eVent</span>alia</a>

    <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
      <ul class="navbar-nav">

        <!--/ Página inicio /-->
        <li class="nav-item">
          <a class="nav-link <?php echo $vista_ACTUAL == "inicio.php" ? "active" : "";?>" href="inicio.php">Inicio</a>
        </li>

        <!--/ Página conócenos /-->
        <li class="nav-item">
          <a class="nav-link <?php echo $vista_ACTUAL == "conocenos.php" ? "active" : "";?>" href="conocenos.php">Conócenos</a>
        </li>


        <!--
        SELECCIÓN DINÁMCA (según si existe sesión)
        ******************************************
        -->
        <?php if (isset($_COOKIE["datosUsuario"])) : // >> Parte con sesión ?>

        <!--/ Página Mi perfil /-->
        <li class="nav-item">
          <a class="nav-link <?php echo $vista_ACTUAL == "menuPerfiles" ? "active" : "";?>" href="perfil_usuario.php?pag=1">Mi perfil</a>
        </li>

        <!--/ Menú eventos /-->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?php echo $vista_ACTUAL == "menuEventos" ? "active" : "";?>" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Eventos</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="ver_eventos.php?pag=1"><i class="bi bi-search"></i> Ver eventos</a>
            <a class="dropdown-item" href="crear_evento.php"><i class="bi bi-calendar-plus"></i> Crear evento</a>
          </div>
        </li>

        <!--/ Menú Cerrar sesión, Login usuario /-->
        <li class="nav-item">
          <a class="nav-link" href="<?php echo basename($_SERVER['PHP_SELF']). "?cerrar_sesion" ?>">Cerrar sesión</a>
        </li>

        <?php else : // >> Parte sin sesión ?>

        <!--/ Menú login y registro /-->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?php echo $vista_ACTUAL == "menuSesiones" ? "active" : "";?>" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Login</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="login.php">Iniciar sesión</a>
            <a class="dropdown-item" href="registro.php">Registrarse ahora</a>
          </div>
        </li>

        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav><!-- FIN Header/Navbar -->

<body><!-- Apertura del cuerpo de la página -->