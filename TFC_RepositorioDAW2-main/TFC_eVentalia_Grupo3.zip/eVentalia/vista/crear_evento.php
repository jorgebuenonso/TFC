<?php
require('../controlador/controlador.php');
controlarVistas();

include('../modelo/evento.php');

if (isset($_POST["crear_evento"])) {
    $evento = new Evento();
    $crear_OK = $evento->crearEvento($_POST, $_FILES['foto'], $datosUsuario["ID_PERSONA"]);

    if ($crear_OK) {
        echo '<script>alert("Se ha creado el evento");</script>';
    }
    else {
        echo '<script>alert("Error al crear el evento");</script>';
    }
}

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Crear evento</h1>
                        <span class="color-text-a">Creación Evento</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Creación Evento
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <?php
    $vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa
    include('modulos_compartidos/MOD_formulario_evento.php');
    ?>
</main>

<?php include('modulos_compartidos/footer.php'); ?>