<?php
require('../controlador/controlador.php');
controlarVistas();

include('../modelo/evento.php');
$evento = new Evento();
$consulta = $evento->mostrarEvento($_GET["id_evento"]);

// Borrado y edición de un evento
if ($consulta["ID_CREADOR"] == $datosUsuario["ID_PERSONA"]) {
    if (isset($_POST["borrar_evento"])) {
        $borrado_OK = $evento->borrarEvento($_GET["id_evento"]);
        
        // Mostrar popup de estado
        if ($borrado_OK) {
            echo '<script>alert("Se ha borrado el evento");</script>';
            echo '<script>window.location.href = "perfil_usuario.php?pag=1";</script>';
        }
        else {
            echo '<script>alert("Error al borrar el evento. Ninguno de los campos ha sido afectado.");</script>';
        }
    }
    else if (isset($_POST["editar_evento"])) {
        $editar_OK = $evento->modificarEvento($_POST, $_FILES['foto'], $_GET["id_evento"]);
        $consulta = $evento->mostrarEvento($_GET["id_evento"]);

        // Mostrar popup de estado
        if ($editar_OK) {
            echo '<script>alert("Se ha editado el evento");</script>';
        }
        else {
            echo '<script>alert("Error al editar el evento. Revise los campos para comprobar errores o posibles campos alterados.");</script>';
        }
    }
}

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Editar evento</h1>
                        <span class="color-text-a">Edición Evento</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Edición Evento
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!--/ Botón para volver /-->
        <br/>
        <div class="container">
            <form action="<?php echo isset($_GET["id_evento"]) ? 'pagina_evento.php?id_evento='. $_GET["id_evento"] : 'ver_eventos.php?pag=1' ; ?>" method="post">
                <button type="submit" class="btn btn-b">Volver al evento</button>
            </form>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <?php
    // Incluir formulario
    $vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa
    include('modulos_compartidos/MOD_formulario_evento.php');
    ?>
</main>

<?php include('modulos_compartidos/footer.php'); ?>