<?php
require('../controlador/controlador.php');
controlarVistas();

/*
·····························································································
·····························································································
*/

// Transformar valores de URL en array
# --------------------------------------------------------------
$queryString = $_SERVER['QUERY_STRING'];
$queryValues = array();
parse_str($_SERVER['QUERY_STRING'], $queryValues);

$params["id_evento"] = isset($params["id_evento"]) ? $params["id_evento"] : "";
$id_evento = isset($queryValues["id_evento"]) ? $queryValues["id_evento"] : "";
# --------------------------------------------------------------


include('../modelo/evento.php');
$evento = new Evento();

$consulta = $evento->mostrarEvento($id_evento);
// Si no hay imagen, reemplazar por defecto
$imagenEvento = isset($consulta['IMAGEN_EVENTO']) ? "fotos_eventos/" . $consulta['IMAGEN_EVENTO'] : "img/favicon.png";

// Comprobar si la subscripción sigue abierta (habilitado hasta el mismo día del evento)
$fechaHoy = new DateTime();
// $fechaHoy->modify('-1 day');
$fechaEvento = new DateTime($consulta["FECHA_HORA"]);
$eventoCerrado = $fechaEvento <= $fechaHoy ? true : false;

// Si el usuario se une al evento o sale del evento
# --------------------------------------------------------------
if ($consulta and $consulta["ID_EVENTO"]) {
  if (isset($_POST["subscribirse"]) and !$eventoCerrado) {
    $evento->agregarUsuarioEvento($consulta["ID_EVENTO"], $datosUsuario["ID_PERSONA"]);
  } else if (isset($_POST["anular_subscripcion"])) {
    $evento->eliminarUsuarioEvento($consulta["ID_EVENTO"], $datosUsuario["ID_PERSONA"]);
  }
}
# --------------------------------------------------------------

// Si el usuario publica un comentario
# --------------------------------------------------------------
$usuarioSubscrito = $evento->comporobarSubscripcion($consulta["ID_EVENTO"], $datosUsuario["ID_PERSONA"]);
if ($usuarioSubscrito or $consulta["ID_CREADOR"] == $datosUsuario["ID_PERSONA"]) {
  if (isset($_POST["publicar_mensaje"])) {
    $evento->insertarMensaje($consulta["ID_EVENTO"], $datosUsuario["ID_PERSONA"], $_POST["mensaje"]);
    header('Location: pagina_evento.php?id_evento=' . $id_evento);
  }
}
# --------------------------------------------------------------

// Si el creador borra un mensaje
# --------------------------------------------------------------
if ($consulta["ID_CREADOR"] == $datosUsuario["ID_PERSONA"] and isset($_POST["borrar_mensaje"])) {
  $evento->borrarMensaje($_POST["borrar_mensaje"]);
}
# --------------------------------------------------------------

$consulta = $evento->mostrarEvento($id_evento);

// Donar a usuario
# --------------------------------------------------------------
if (isset($_POST["donar"]) and $consulta and $_POST['cantidad']) {
  $usuario = $persona->mostrarPerfil($datosUsuario["ID_PERSONA"]);

  $cantidad = $_POST['cantidad'];

  if ($cantidad > 0) {
    $porcentaje_CREADOR = $cantidad * 0.8;
    $porcentaje_EVENTALIA = $cantidad * 0.2;

    // Formato de datos para txt
    $info = "ID_CREADOR: {$consulta['ID_CREADOR']}\r\nDONANTE: {$usuario['EMAIL']}\r\nTOTAL: {$cantidad}€\r\n80% CREADOR: {$porcentaje_CREADOR}€\r\n20% EVENTALIA: {$porcentaje_EVENTALIA}€\r\r==================\r\r";

    $file = '../LOGS/donaciones.txt';
    file_put_contents($file, $info, FILE_APPEND);
  } else {
    echo '<script>alert("¡La cantidad mínima de donación es 1 € ' . $usuario["NOMBRE"] . '!");</script>';
  }
}
# --------------------------------------------------------------

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">
  <?php if ($consulta and $consulta["ID_EVENTO"]) : // Si se encuentra el evento 
  ?>
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Pagina Evento</h1>
              <span class="color-text-a">Pagina Evento: <?php echo $consulta["NOMBRE"] ?></span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="inicio.php">Inicio</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Pagina Evento
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <!-- ======= Sección de información del evento ======= -->
    <section class="agent-single">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="row">

              <!--/ Imagen del evento /-->
              <div class="col-md-6">
                <div class="agent-avatar-box">
                  <img src="../assets/<?php echo $imagenEvento ?>" alt="" class="agent-avatar img-fluid">
                </div>
              </div>

              <!--/ Datos del evento /-->
              <div class="col-md-5 section-md-t3">
                <div class="agent-info-box">
                  <!--/ Nombre del evento /-->
                  <div class="agent-title">
                    <div class="title-box-d">
                      <h3 class="title-d">
                        <?php echo $consulta['NOMBRE']; ?>
                      </h3>
                    </div>
                  </div>
                  <!--/ Descripcción y datos del evento /-->
                  <div class="agent-content mb-3">
                    <h4><strong>Descripcción: </strong><span class="color-text-a"><?php echo $consulta["DESCRIPCION"]; ?></span></h4>
                    <div class="info-agents color-a">
                      <hr>
                      <h4><strong>Creador: </strong><span class="color-text-a"><?php echo $consulta['NOMBRE_CREADOR'] . " " . $consulta['APELLIDOS_CREADOR']; ?></a></span></h4>
                      <h4><strong>Provincia: </strong><span class="color-text-a"><?php echo $consulta["NOMBRE_PROVINCIA"]; ?></span></h4>
                      <h4><strong>Categoría: </strong><span class="color-text-a"><?php echo $consulta["CATEGORIA"] ?></span></h4>
                      <h4><strong>Fecha: </strong><span class="color-text-a"><?php echo $consulta["FECHA_HORA"]; ?></span></h4>
                      <hr>
                      <h4><strong>Plazas ocupadas: </strong><span class="color-text-a"><?php echo $consulta["SUBSCRITOS"]; ?> de <span class="color-text-a"><?php echo $consulta["AFORO"] ?></span></h4>
                    </div>
                  </div>
                </div>
                <?php if ($consulta['ID_CREADOR'] != $datosUsuario["ID_PERSONA"]) { ?>
                  <a href="perfil_usuario.php?id_creador=<?php echo $consulta['ID_CREADOR']; ?>">
                    <button type="submit" class="btn btn-b" name="ver_perfil">Ver perfil del creador</button>
                  </a>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>
        <br />

        <!--/ Opciones del evento /-->
        <?php if ($consulta["ID_CREADOR"] == $datosUsuario["ID_PERSONA"]) : // Si el evento pertenece al usuario 
        ?>
          <form action="editar_evento.php" method="GET">
            <button type="submit" class="btn btn-b" name="id_evento" value="<?php echo $id_evento; ?>"><i class="bi bi-pencil-square"></i> Editar evento</button>
          </form>
        <?php else : // Si el evento no pertenece al usuario 
        ?>
          <form action="" method="post">
            <?php if (!$evento->comporobarSubscripcion($consulta["ID_EVENTO"], $datosUsuario["ID_PERSONA"])) : // Comprobar si está subscrito 
            ?>
              <?php if ($consulta["SUBSCRITOS"] < $consulta["AFORO"]) : // Opción según aforo 
              ?>
                <?php if (!$eventoCerrado) : // Comprobar si se ha pasado la fecha 
                ?>
                  <button type="submit" class="btn btn-b" name="subscribirse"><i class="bi bi-check-circle"></i> Unirse a evento</button>
                <?php else : ?>
                  <button type="submit" class="btn btn-a" name="subscribirse" disabled>Evento cerrado</button>
                <?php endif; ?>
              <?php else : ?>
                <button type="submit" class="btn btn-a" name="subscribirse" disabled>Aforo completo</button>
              <?php endif; ?>
            <?php else : ?>
              <button type="submit" class="btn btn-b" name="anular_subscripcion"><i class="bi bi-dash-circle"></i> Anular subscripción</button>
            <?php endif; ?>
            <br /><br />
            <button type="button" class="btn btn-b" name="donar" onclick="donarEvento(<?= $consulta['ID_EVENTO'] ?>)"><i class="bi bi-cash-coin"></i> Donar al evento</button>
          </form>
        <?php endif; ?>
      </div>
    </section><!--/ FIN Sección del perfil de usuario /-->

    <!-- ======= Comentarios del evento ======= -->
    <section class="news-single nav-arrow-b">
      <div class="container">
        <div class="row">

          <?php if ($usuarioSubscrito or $consulta["ID_CREADOR"] == $datosUsuario["ID_PERSONA"]) : ?>
            <!--/ Escribir Comentario /-->
            <div class="form-comments">
              <div class="title-box-d">
                <br />
                <h3 class="title-d">Dejar comentario</h3>
              </div>
              <form class="form-a" method="POST">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <div class="form-group">
                      <label for="textMessage">Introducir mensaje</label>
                      <textarea id="textMessage" class="form-control" placeholder="* Comentario" name="mensaje" cols="45" rows="8" required></textarea>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-b" name="publicar_mensaje">Publicar mensaje</button>
                  </div>
                </div>
              </form>
            </div><!--/ FIN Escribir Comentario /-->
          <?php endif; ?>

          <!--/ Seccion de comentarios /-->
          <div class="col-md-10 offset-md-1 col-lg-10 offset-lg-1">
            <div class="title-box-d">
              <br />
              <h3 class="title-d">Comentarios</h3>
            </div>
            <div class="box-comments">
              <ul class="list-comments">
                <?php foreach ($evento->mostrarMensajes($consulta["ID_EVENTO"]) as $key => $fila) :
                  // Obtener imagen de usuario
                  $imagenPersona = $persona->mostrarPerfil($fila['ID_PERSONA'])['IMAGEN_PERSONA'] ? "fotos_personas/" . $persona->mostrarPerfil($fila['ID_PERSONA'])['IMAGEN_PERSONA'] : "img/favicon.png";
                ?>
                  <li>
                    <div class="comment-avatar">
                      <img src="../assets/<?php echo $imagenPersona; ?>" alt="">
                    </div>
                    <div class="comment-details">
                      <?php if ($consulta["ID_CREADOR"] == $datosUsuario["ID_PERSONA"]) : // Si el evento pertenece al usuario 
                      ?>
                        <form action="" method="post">
                          <button type="submit" class="btn btn-danger" name="borrar_mensaje" value="<?php echo $fila['ID_MENSAJE'] ?>">Borrar mensaje</button>
                        </form>
                      <?php endif; ?>
                      <!--/ Nombre usuario /-->
                      <h4 class="comment-author"><?php echo $fila["NOMBRE_USUARIO"] . " " . $fila["APELLIDOS_USUARIO"]; ?></h4>
                      <!--/ Hora y fecha del mensaje /-->
                      <span><?php echo $fila["HORA_ENVIO"]; ?></span>
                      <!--/ Contenido del mensaje /-->
                      <p class="comment-description">
                        <?php echo $fila["MENSAJE"]; ?>
                      </p>
                    </div>
                  </li>
                <?php endforeach; ?>
              </ul>
            </div><!--/ FIN Seccion de comentarios /-->

          </div>
        </div>
      </div>
    </section><!-- FIN Comentarios del evento -->

  <?php else : // En caso de no existir evento o error 
  ?>
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">¿Y el evento?</h1>
              <span class="color-text-a">¡Parece que ha habido un error!<br />Inténtalo de nuevo más tarde<br /></span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="inicio.php">Inicio</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Pagina Evento
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- FIN Título/Breadcrumbs -->
  <?php endif; ?>

</main><!-- End #main -->

<!-- ======= Menu simulación donación a creador ======= -->
<div id="modal" class="modal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Dona al creador del evento</h5>

        <button type="button" class="btn-close" aria-label="Close" onclick="cerrarModal()"></button>
      </div>
      <div class="modal-body">
        <p>¡Apoya al creador del evento! Ten en cuenta que la aplicación <u><strong>se reserva una comisión del 20%</strong></u> para cubrir gastos de mantenimiento y mejoras continuas en la plataforma.</p>
        <p>Para donar introduce los datos de tu tarjeta:</p>
        <form id="formularioDonacion" action="" method="post" onsubmit="return validarFormulario()">
          <input type="hidden" name="idEvento" value="<?php echo $consulta["ID_EVENTO"] ?>">
          <div class="form-group">
            <label>Email:</label>
            <input class="form-control" name="email" type="email" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" required>
          </div>

          <div class="form-group">
            <label>Cantidad:</label>
            <input class="form-control" name="cantidad" type="number" required>
          </div>
          <div class="form-group">
            <label>Titular:</label>
            <input class="form-control" name="titular" type="text" required>
          </div>
          <div class="form-group">
            <label>Número de tarjeta:</label>
            <input class="form-control" name="tarjeta" type="text" pattern="[0-9]{20}" maxlength="20" minlength="20" required>
          </div>
          <div class="row">
            <div class="form-group col-6">
              <label>Fecha de caducidad:</label>
              <input class="form-control" name="fecha" type="date" required>
              <div id="fechaError" class="error"></div>
            </div>
            <div class="form-group col-6">
              <label>CVV:</label>
              <input class="form-control" name="cvv" type="text" pattern="[0-9]{3}" maxlength="3" minlength="3" required>
            </div>
          </div>
          <div class="form-group mt-4">
            <input class="btn btn-primary" type="submit" name="donar" value="¡Donar!">
          </div>
          <div class="form-group mt-4">
            <img style="filter: brightness(1.1);mix-blend-mode: multiply; float: right;" src="../assets/img/logoCard.png" alt="logoCard" width=25% height=35%>
          </div>
        </form>
      </div>
    </div>
  </div>
</div><!-- Menu simulación donación a creador -->

<!-- Funciones JS para popup de donación a creador evento -->
<script>
  function donarEvento(idEvento) {
    document.querySelector("#modal").classList.add("d-block");
  }

  function cerrarModal() {
    document.querySelector("#modal").classList.remove("d-block");
  }

  function validarFormulario() {
    const fechaInput = document.getElementById("formularioDonacion").elements["fecha"].value;
    const fechaActual = new Date().toISOString().split("T")[0];

    if (fechaInput < fechaActual) {
      document.getElementById("fechaError").innerHTML = "La fecha de caducidad no puede ser anterior a la fecha actual.";
      return false;
    }
    
    return true;
  }
</script>

<?php include('modulos_compartidos/footer.php'); ?>