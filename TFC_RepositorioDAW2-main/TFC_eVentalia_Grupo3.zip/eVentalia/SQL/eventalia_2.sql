-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-06-2023 a las 20:50:52
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `eventalia_2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat_evento`
--

CREATE TABLE `chat_evento` (
  `ID_MENSAJE` bigint(20) UNSIGNED NOT NULL,
  `ID_EVENTO` smallint(6) UNSIGNED NOT NULL,
  `ID_PERSONA` int(6) UNSIGNED NOT NULL,
  `MENSAJE` text COLLATE utf8_spanish_ci NOT NULL,
  `HORA_ENVIO` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `chat_evento`
--

INSERT INTO `chat_evento` (`ID_MENSAJE`, `ID_EVENTO`, `ID_PERSONA`, `MENSAJE`, `HORA_ENVIO`) VALUES
(1, 1, 1, 'Otra prueba de mensaje para comprobar si de verdad se inserta como yo quiero o si hay que hacer algún cambio porque soy un paquete y se me da muy mal programar :,)', '2023-05-24 19:21:50'),
(2, 1, 6, 'Voy cuajadísimo', '2023-05-24 19:23:01'),
(3, 1, 3, 'Funciona!', '2023-05-24 19:41:52'),
(9, 2, 1, 'Hola gente, estoy subscrito y puedo hablar.', '2023-05-30 11:36:15'),
(10, 2, 1, 'Me he vuelto a unir!', '2023-05-30 11:36:47'),
(11, 2, 3, 'Buenas! Soy el organizador', '2023-05-30 11:38:03');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

CREATE TABLE `direccion` (
  `ID_DIRECCION` int(10) UNSIGNED NOT NULL,
  `NOMBRE` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `CP` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `direccion`
--

INSERT INTO `direccion` (`ID_DIRECCION`, `NOMBRE`, `CP`) VALUES
(1, 'Calle del Sol, 123', 28001),
(2, 'Avenida de los Pájaros, 456', 8012),
(3, 'Carrer del Mar, 789', 46011),
(4, 'Paseo de la Luna, 234', 1001),
(5, 'Calle de los Pinos, 567', 29010),
(6, 'Paseo de los Cerezos, 456', 50001),
(7, 'Carrer de la Rosa, 123', 7002),
(8, 'Calle de las Flores, 789', 3001),
(9, 'Avenida del Mar, 890', 48001),
(10, 'Avenida de las Palmeras, 234', 18001);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `ID_EVENTO` smallint(6) UNSIGNED NOT NULL,
  `ID_CREADOR` int(6) UNSIGNED NOT NULL,
  `AFORO` smallint(6) UNSIGNED NOT NULL,
  `NOMBRE` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `FECHA_HORA` date NOT NULL,
  `DESCRIPCION` text COLLATE utf8_spanish_ci NOT NULL,
  `IMAGEN_EVENTO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `CATEGORIA` enum('EXCURSION','FIESTA','VIAJES','MUSICA','DEPORTES') COLLATE utf8_spanish_ci DEFAULT NULL,
  `PROVINCIA` int(6) UNSIGNED NOT NULL,
  `FECHA_CREACION` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`ID_EVENTO`, `ID_CREADOR`, `AFORO`, `NOMBRE`, `FECHA_HORA`, `DESCRIPCION`, `IMAGEN_EVENTO`, `CATEGORIA`, `PROVINCIA`, `FECHA_CREACION`) VALUES
(1, 3, 20, 'Concierto en Zaragoza', '2023-06-08', 'Concierto de Shakira', '1685660524concierto3.jpg', 'MUSICA', 5, '2023-04-27 14:51:44'),
(2, 3, 10, 'Excursión al retiro', '2023-06-27', 'Haremos concursos de cuerda', '1685660640deporte1.jpg', 'EXCURSION', 1, '2023-04-27 14:53:50'),
(3, 3, 5, 'Viaje con amigos', '2023-06-10', 'Busco amigos para viajar este verano', '1685660592fiesta.jpg', 'VIAJES', 1, '2023-04-27 14:54:45'),
(10, 1, 100, 'Viaje con amigos', '2023-06-14', 'Viajaremos de Sevilla a Cádiz', '1685722169Tips-para-viajar-2.gif', 'VIAJES', 3, '2023-05-14 20:11:39'),
(12, 1, 25, 'Actividad deportida de la comunidad Asturiana', '2023-09-29', 'Haremos una carrera por el pueblo', '1685722300asturias.jpg', 'DEPORTES', 4, '2023-05-15 20:43:55'),
(16, 6, 64, 'Viaje por la costa brava', '2023-06-17', 'Viajo con mi novia y buscamos aventureros como nosotros', '1685722500costa.jpg', 'VIAJES', 4, '2023-05-17 08:19:40'),
(19, 6, 7, 'Karaoke en Zaragoza', '2023-11-11', 'Busco gente para cantarnos algo', '1685723024foto-gran-fiesta-lifeder-min-1024x707.jpg', 'FIESTA', 5, '2023-05-17 11:02:05'),
(20, 6, 49, 'Excursión a centro de refugio de gatos', '2024-09-13', 'Me gustaría encontrar gente para poder ayudar a los gatos del refugio', '1685723367gatos.jpg', 'EXCURSION', 1, '2023-05-17 11:05:34'),
(21, 6, 77, 'Excursión a mi pueblo', '2023-07-07', 'Vienen las fiestas del pueblo y quiero compañeros de fatiga', '1685722651pueblo.jpg', 'EXCURSION', 2, '2023-05-17 11:15:09'),
(22, 6, 6, 'Correr en la playa', '2023-11-08', 'Estoy buscando gente en Barcelona para correr por la playa', '1685723233playa.jpg', 'DEPORTES', 2, '2023-05-17 11:15:46'),
(26, 3, 6, 'Partido de fútbol 11', '2023-07-27', 'Busco gente para jugar un partido de fútbol', '1685660690organizar_partido_futbol.jpg', 'DEPORTES', 4, '2023-05-22 18:56:26'),
(32, 1, 18, 'Excursión en El Escorial', '2023-06-29', 'Realizaremos diferentes eventos dentro de la excursión', '1685722240excursion.jpg', 'EXCURSION', 1, '2023-05-26 09:40:18'),
(36, 6, 5, 'Viaje con amigos', '2023-06-30', 'Estoy buscando gente para irnos de vacaciones este verano', '1685722590viaje_amigos.jpg', 'VIAJES', 3, '2023-05-30 10:49:43'),
(37, 1, 10, 'Sala de fiestas', '2023-06-02', 'Salida a sala de fiestas', '1685722067foto-gran-fiesta-lifeder-min-1024x707.jpg', 'FIESTA', 1, '2023-05-30 20:33:19'),
(42, 1, 10, 'Concierto En Madrid', '2023-06-02', 'Concierto de Rafael', '1685722127cantante.jpg', 'FIESTA', 1, '2023-06-01 16:55:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipio`
--

CREATE TABLE `municipio` (
  `ID_MUNICIPIO` int(6) UNSIGNED NOT NULL,
  `NOMBRE` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `DIRECCION` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `municipio`
--

INSERT INTO `municipio` (`ID_MUNICIPIO`, `NOMBRE`, `DIRECCION`) VALUES
(1, 'Utebo', 6),
(2, 'Colmenar Viejo', 1),
(3, 'Alcobendas', 2),
(4, 'Utrera', 9),
(5, 'Cádiz', 10),
(6, 'Sabadell', 7),
(7, 'Girona', 3),
(8, 'Calatayud', 4),
(9, 'Oviedo', 8),
(10, 'Gijón', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personas`
--

CREATE TABLE `personas` (
  `ID_PERSONA` int(6) UNSIGNED NOT NULL,
  `NOMBRE` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `APELLIDOS` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `PASSWORD` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `DIRECCION` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `IMAGEN_PERSONA` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `TELEFONO` int(9) UNSIGNED DEFAULT NULL,
  `FECHA_NACIMIENTO` date NOT NULL,
  `DESCRIPCION` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `personas`
--

INSERT INTO `personas` (`ID_PERSONA`, `NOMBRE`, `APELLIDOS`, `EMAIL`, `PASSWORD`, `DIRECCION`, `IMAGEN_PERSONA`, `TELEFONO`, `FECHA_NACIMIENTO`, `DESCRIPCION`) VALUES
(1, 'Rubén', 'Lozano', 'test@gmail.com', '$2y$10$dObC3C4/Skg1wI1L1d7nOetPfEox9PGTaxRqUcEvX.yrujs8RLEB2', 'Doctor Severo Ochoa', '1685445621Test_Image4.jpg', 123456789, '2002-03-28', 'Hello word! Esta es mi descripción de ejemplo. Hay qye hacer muchas pruebas para sacar un 10!'),
(3, 'Juan', 'Pablo', 'pablogarcia@gmail.com', '$2y$10$dObC3C4/Skg1wI1L1d7nOetPfEox9PGTaxRqUcEvX.yrujs8RLEB2', 'Testoso', NULL, 1231231, '1987-05-18', '¡Saludos! Soy Pablo, un entusiasta de la vida social. Disfruto de la compañía de mis amigos y siempr'),
(6, 'Marcos', 'Pérez Gonzalez', 'marcosperez@gmail.com', '$2y$10$dObC3C4/Skg1wI1L1d7nOetPfEox9PGTaxRqUcEvX.yrujs8RLEB2', 'Imagen PNG City', '1684440751agent-1.jpg', 1231231, '2001-02-07', '¡Hola, soy Marcos! Soy un espíritu aventurero y siempre estoy en busca de nuevas experiencias. Me en'),
(11, 'Raúl', 'González', 'Raulgonzalez@gmail.com', '$2y$10$dObC3C4/Skg1wI1L1d7nOetPfEox9PGTaxRqUcEvX.yrujs8RLEB2', 'Calle Alegria', '1684949402RubenLozano.jpg', 622236589, '1956-11-24', 'Saludos, soy Raúl. Me considero una persona extrovertida y amigable. Siempre estoy buscando oportuni'),
(14, 'Laura', 'Bueno', 'laurabueno@gmail.com', '$2y$10$dObC3C4/Skg1wI1L1d7nOetPfEox9PGTaxRqUcEvX.yrujs8RLEB2', 'Calle valencia', '1685660326Kim-Kardashian.jpg', 123456789, '2000-01-01', 'ï¿½Hola! Soy Laura, una persona sociable y siempre lista para hacer planes emocionantes. Disfruto mu'),
(15, 'Carolina', 'Molina', 'carolmolina@gmail.com', '$2y$10$dObC3C4/Skg1wI1L1d7nOetPfEox9PGTaxRqUcEvX.yrujs8RLEB2', 'IES Ciudad Escolar', NULL, 123456789, '1999-01-01', '¡Hola a todos! Soy Carolina, una persona sociable y amante de los planes en grupo. Me encanta organi');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE `provincia` (
  `ID_PROVINCIA` int(6) UNSIGNED NOT NULL,
  `NOMBRE` varchar(50) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `provincia`
--

INSERT INTO `provincia` (`ID_PROVINCIA`, `NOMBRE`) VALUES
(1, 'Madrid'),
(2, 'Barcelona'),
(3, 'Sevilla'),
(4, 'Asturias'),
(5, 'Zaragoza');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resena`
--

CREATE TABLE `resena` (
  `ID_RESENA` int(6) UNSIGNED NOT NULL,
  `COMENTARIO` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `PUNTUACION` int(5) NOT NULL,
  `ID_EVENTO` smallint(6) UNSIGNED NOT NULL,
  `ID_SUSCRIPTOR` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `resena`
--

INSERT INTO `resena` (`ID_RESENA`, `COMENTARIO`, `PUNTUACION`, `ID_EVENTO`, `ID_SUSCRIPTOR`) VALUES
(3, '\"Quiero agradecer al equipo organizador por hacer posible este maravilloso evento. Los ponentes fueron inspiradores y pude hacer conexiones valiosas con otros participantes. ¡Fue una experiencia enriquecedora!\"', 3, 12, 11),
(4, '\"No tengo palabras para describir lo impresionante que fue este evento. La calidad de los oradores y la variedad de temas tratados fue excepcional. Definitivamente ha superado mis expectativas y ha sido una experiencia enriquecedora.\"', 5, 1, 3),
(5, '\"Sin duda, este evento ha dejado una huella en mí. Las temáticas abordadas fueron relevantes y los talleres prácticos me ayudaron a adquirir nuevas habilidades. ¡Recomendaría este evento a cualquier persona interesada en el tema!\"', 4, 10, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subscripciones`
--

CREATE TABLE `subscripciones` (
  `ID_EVENTO` smallint(6) UNSIGNED NOT NULL,
  `ID_PERSONA` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `subscripciones`
--

INSERT INTO `subscripciones` (`ID_EVENTO`, `ID_PERSONA`) VALUES
(19, 1),
(42, 6),
(42, 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `chat_evento`
--
ALTER TABLE `chat_evento`
  ADD PRIMARY KEY (`ID_MENSAJE`),
  ADD KEY `FK_evento_chat` (`ID_EVENTO`),
  ADD KEY `FK_persona_chat` (`ID_PERSONA`);

--
-- Indices de la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD PRIMARY KEY (`ID_DIRECCION`);

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`ID_EVENTO`),
  ADD KEY `FK_provincia` (`PROVINCIA`),
  ADD KEY `FK_creador` (`ID_CREADOR`);

--
-- Indices de la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`ID_MUNICIPIO`),
  ADD KEY `FK_direccion` (`DIRECCION`);

--
-- Indices de la tabla `personas`
--
ALTER TABLE `personas`
  ADD PRIMARY KEY (`ID_PERSONA`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`);

--
-- Indices de la tabla `provincia`
--
ALTER TABLE `provincia`
  ADD PRIMARY KEY (`ID_PROVINCIA`);

--
-- Indices de la tabla `resena`
--
ALTER TABLE `resena`
  ADD PRIMARY KEY (`ID_RESENA`),
  ADD KEY `FK_evento_resena` (`ID_EVENTO`),
  ADD KEY `FK_subscriptor_resena` (`ID_SUSCRIPTOR`);

--
-- Indices de la tabla `subscripciones`
--
ALTER TABLE `subscripciones`
  ADD KEY `FK_evento_sub` (`ID_EVENTO`),
  ADD KEY `FK_persona_sub` (`ID_PERSONA`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `chat_evento`
--
ALTER TABLE `chat_evento`
  MODIFY `ID_MENSAJE` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `direccion`
--
ALTER TABLE `direccion`
  MODIFY `ID_DIRECCION` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `ID_EVENTO` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de la tabla `municipio`
--
ALTER TABLE `municipio`
  MODIFY `ID_MUNICIPIO` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `personas`
--
ALTER TABLE `personas`
  MODIFY `ID_PERSONA` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `provincia`
--
ALTER TABLE `provincia`
  MODIFY `ID_PROVINCIA` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `resena`
--
ALTER TABLE `resena`
  MODIFY `ID_RESENA` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `chat_evento`
--
ALTER TABLE `chat_evento`
  ADD CONSTRAINT `FK_evento_chat` FOREIGN KEY (`ID_EVENTO`) REFERENCES `eventos` (`ID_EVENTO`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_persona_chat` FOREIGN KEY (`ID_PERSONA`) REFERENCES `personas` (`ID_PERSONA`) ON DELETE CASCADE;

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `FK_creador` FOREIGN KEY (`ID_CREADOR`) REFERENCES `personas` (`ID_PERSONA`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_provincia` FOREIGN KEY (`PROVINCIA`) REFERENCES `provincia` (`ID_PROVINCIA`) ON DELETE CASCADE;

--
-- Filtros para la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD CONSTRAINT `FK_direccion` FOREIGN KEY (`DIRECCION`) REFERENCES `direccion` (`ID_DIRECCION`);

--
-- Filtros para la tabla `resena`
--
ALTER TABLE `resena`
  ADD CONSTRAINT `FK_evento_resena` FOREIGN KEY (`ID_EVENTO`) REFERENCES `eventos` (`ID_EVENTO`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_subscriptor_resena` FOREIGN KEY (`ID_SUSCRIPTOR`) REFERENCES `personas` (`ID_PERSONA`) ON DELETE CASCADE;

--
-- Filtros para la tabla `subscripciones`
--
ALTER TABLE `subscripciones`
  ADD CONSTRAINT `FK_evento_sub` FOREIGN KEY (`ID_EVENTO`) REFERENCES `eventos` (`ID_EVENTO`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_persona_sub` FOREIGN KEY (`ID_PERSONA`) REFERENCES `personas` (`ID_PERSONA`) ON DELETE CASCADE;

DELIMITER $$
--
-- Eventos
--
CREATE DEFINER=`root`@`localhost` EVENT `eliminar_subscripciones_eventos_expirados` ON SCHEDULE EVERY 1 MINUTE STARTS '2023-05-31 12:49:36' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  DELETE subscripciones
  FROM subscripciones
  LEFT JOIN eventos ON subscripciones.ID_EVENTO = eventos.ID_EVENTO
  WHERE eventos.FECHA_HORA <= DATE_SUB(CURDATE(), INTERVAL 1 WEEK);
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
