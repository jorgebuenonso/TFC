<?php

require_once("conexion.php");

class Evento extends Conexion {
    private $conn = null;

    public function __construct() {
        $this->conn = parent::conexion();
    }


    function todosEventosUsuario($id_usuario) {
        try {
            $sql = "SELECT IMAGEN_EVENTO FROM eventos WHERE IMAGEN_EVENTO IS NOT NULL AND ID_CREADOR = :ID_CREADOR";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_CREADOR", $id_usuario);
            $stmt->execute();
            $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> INFO DE UN EVENTO
    function mostrarEvento($id_evento) {
        try {
            $sql = "SELECT
                eventos.*,
                personas.NOMBRE AS NOMBRE_CREADOR,
                personas.APELLIDOS AS APELLIDOS_CREADOR,
                provincia.NOMBRE AS NOMBRE_PROVINCIA,
                count(subscripciones.ID_EVENTO) AS SUBSCRITOS
            FROM eventos
                LEFT JOIN personas ON eventos.ID_CREADOR = personas.ID_PERSONA
                LEFT JOIN provincia ON eventos.PROVINCIA = provincia.ID_PROVINCIA
                LEFT JOIN subscripciones ON eventos.ID_EVENTO = subscripciones.ID_EVENTO
            WHERE eventos.ID_EVENTO = :ID_EVENTO";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->execute();
            $registros = $stmt->fetch();
    
            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> TODOS LOS REGISTROS (con filtro)
    function buscarEvento($params, &$pag_actual, &$total_pag, $id_usuario=false, bool $ocultarExpirado=false) {
        try {
            // Comprobación de parámetros
            # --------------------------------------------------------------
            $params["nombre"] = isset($params["nombre"]) ? $params["nombre"] : "";
            $params["categoria"] = isset($params["categoria"]) ? $params["categoria"] : "";
            $params["provincia"] = isset($params["provincia"]) ? filter_var($params["provincia"], FILTER_SANITIZE_NUMBER_INT) : "";
            $params["aforo"] = isset($params["aforo"]) ? $params["aforo"] : "";
            $params["mostrar"] = isset($params["mostrar"]) ? $params["mostrar"] : "";
            $params["pag"] = isset($params["pag"]) ? filter_var($params["pag"], FILTER_SANITIZE_NUMBER_INT) : 1;    // Filtra la página en caso de contener errores
            # --------------------------------------------------------------


            // Ajustar filtros de búsqueda
            # --------------------------------------------------------------
            $params["nombre"] = "%". $params["nombre"] ."%";
            $params["categoria"] = "%". $params["categoria"] ."%";

            $queryProvincia = "";
            if ($params["provincia"] != "") {
                $queryProvincia = "AND eventos.PROVINCIA = :PROVINCIA";
            }
            else {
                $queryProvincia = "AND eventos.PROVINCIA >= :PROVINCIA";
            }

            // Si el dato no es válido, aplicar máximo valor de dato en BD
            if ($params["aforo"] == "" or $params["aforo"] > 65535 or $params["aforo"] <= 0) {
                $params["aforo"] = 65535;
            }

            // Ajustar filtro para "página"
            if ($params["pag"] == "" or $params["pag"] <= "0") {
                $params["pag"] = 1;
            }

            // Si se quieren los eventos de un usuario concreto
            $queryCreador = "";
            if ($id_usuario) {
                $queryCreador = "AND eventos.ID_CREADOR = :ID_CREADOR";
            }
            else {
                $queryCreador = "AND eventos.ID_CREADOR >= :ID_CREADOR";
            }

            // Si se quieren filtrar los eventos (creados, subscritos o todos)
            $queryMostrar = "";
            $mostrar_BIND = false;
            if (!$ocultarExpirado) {
                if ($params["mostrar"] != "Creados" or $params["mostrar"] != "Subscritos") {
                    $params["mostrar"] == "Creados";
                }

                if ($params["mostrar"] == "Subscritos") {
                    $mostrar_BIND = true;
                    $queryCreador = "";
                    $queryMostrar = "AND subscripciones.ID_PERSONA = :ID_USUARIO";
                }
            }

            // Si se quieren ocultar los eventos expirados
            $queryExpirado = "";
            if ($ocultarExpirado) {
                $queryExpirado = "AND eventos.FECHA_HORA >= DATE_SUB(CURDATE(), INTERVAL 1 WEEK)";
            }
            # --------------------------------------------------------------

            // Calcular registros totales
            # --------------------------------------------------------------
            $sql = "SELECT
                COUNT(*) AS TOTAL_REGISTROS FROM `eventos`
                LEFT JOIN provincia ON eventos.PROVINCIA = provincia.ID_PROVINCIA
                LEFT JOIN subscripciones ON eventos.ID_EVENTO = subscripciones.ID_EVENTO
            WHERE
                eventos.NOMBRE LIKE :NOMBRE
                {$queryExpirado}
                AND eventos.AFORO BETWEEN 0 AND :AFORO_MAX
                AND eventos.CATEGORIA LIKE :CATEGORIA
                {$queryProvincia}
                {$queryCreador}
                {$queryMostrar}";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':NOMBRE', $params["nombre"]);
            $stmt->bindValue(':AFORO_MAX', $params["aforo"]);
            $stmt->bindValue(':CATEGORIA', $params["categoria"]);
            $stmt->bindValue(':PROVINCIA', $params["provincia"]);
            if (!$mostrar_BIND) {
                $stmt->bindValue(':ID_CREADOR', $id_usuario);
            }
            else {
                $stmt->bindValue(':ID_USUARIO', $id_usuario);
            }
            $stmt->execute();
            $total_registros = $stmt->fetch()["TOTAL_REGISTROS"];
            # --------------------------------------------------------------


            // Paginación de la búsqueda
            # --------------------------------------------------------------
            $limite = 6;
            $total_pag = ceil($total_registros / $limite) >= 1 ? ceil($total_registros / $limite) : 1;  // Total de páginas disponibles

            $pag_actual = (isset($_GET['pag']) and $_GET['pag'] >= 1) ? $_GET['pag'] : "1";
            if ($pag_actual > $total_pag) {
              $pag_actual = $total_pag;
            }

            $offset = ($pag_actual - 1) * $limite;
            # --------------------------------------------------------------

            
            // Consulta paginada
            $sql = "SELECT
                eventos.*, provincia.NOMBRE AS NOMBRE_PROVINCIA, COUNT(subscripciones.ID_EVENTO) AS SUBSCRITOS FROM `eventos`
                LEFT JOIN provincia ON eventos.PROVINCIA = provincia.ID_PROVINCIA
                LEFT JOIN subscripciones ON eventos.ID_EVENTO = subscripciones.ID_EVENTO
            WHERE
                eventos.NOMBRE LIKE :NOMBRE
                {$queryExpirado}
                AND eventos.AFORO BETWEEN 0 AND :AFORO_MAX
                AND eventos.CATEGORIA LIKE :CATEGORIA
                {$queryProvincia}
                {$queryCreador}
                {$queryMostrar}
            GROUP BY eventos.ID_EVENTO
            ORDER BY eventos.FECHA_HORA ASC
            LIMIT {$offset}, {$limite}";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':NOMBRE', $params["nombre"]);
            $stmt->bindValue(':AFORO_MAX', $params["aforo"]);
            $stmt->bindValue(':CATEGORIA', $params["categoria"]);
            $stmt->bindValue(':PROVINCIA', $params["provincia"]);
            if (!$mostrar_BIND) {
                $stmt->bindValue(':ID_CREADOR', $id_usuario);
            }
            else {
                $stmt->bindValue(':ID_USUARIO', $id_usuario);
            }
            $stmt->execute();
            $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> ÚLTIMOS REGISTROS (según fecha de creación)
    function ultimosEventos() {
        try {
            $sql = "SELECT eventos.*, provincia.NOMBRE AS NOMBRE_PROVINCIA FROM `eventos` LEFT JOIN PROVINCIA ON provincia.ID_PROVINCIA = eventos.PROVINCIA ORDER BY eventos.FECHA_CREACION DESC LIMIT 6";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> GUARDAR IMAGEN EN EVENTO
    private function guardarImagen($datosImagen, $id_evento=false) {
        try {
            $nombreImagen = null;     // En caso de no haber imagen se inserta vacio

            if (strlen($datosImagen['name'][0]) > 0) {
                // Datos de la imagen
                $nombreImagen = time(). $datosImagen['name'][0]; // Concatenar tiempo actual para evitar nombres duplicados
                $imagenTmpPath = $datosImagen['tmp_name'][0];

                // Subir imagen al directorio
                $destino = '../assets/fotos_eventos/'. $nombreImagen;
                move_uploaded_file($imagenTmpPath, $destino);
            }

            if ($id_evento) {
                $sql = "UPDATE eventos SET IMAGEN_EVENTO = :IMAGEN_EVENTO WHERE ID_EVENTO = :ID_EVENTO";
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue("IMAGEN_EVENTO", $nombreImagen);
                $stmt->bindValue("ID_EVENTO", $id_evento);
                $stmt->execute();
            }
            else {
                $ultimo_id = $this->conn->lastInsertId();

                $sql = "UPDATE eventos SET IMAGEN_EVENTO = :IMAGEN_EVENTO WHERE ID_EVENTO = :ID_EVENTO";
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue("IMAGEN_EVENTO", $nombreImagen);
                $stmt->bindValue("ID_EVENTO", $ultimo_id);
                $stmt->execute();
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> BORRAR IMAGEN (eliminar del directorio y BD)
    public function borrarImagen($nombreImagen) {
        try {
            // Borrar archivo del directorio de imágenes
            if ($nombreImagen) {
                $rutaImagen = '../assets/fotos_eventos/'. $nombreImagen;    // Ruta imagen
                file_exists($rutaImagen) ? unlink($rutaImagen) : false;     // Borrar imagen
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> CREAR EVENTO (asociado a un usuario)
    function crearEvento($params, $files, $id_creador) {
        try {
            // Validar fecha
            if (strtotime($params["fecha"]) >= strtotime(date('Y-m-d'))) {
                $sql = "INSERT INTO eventos (ID_CREADOR, AFORO, NOMBRE, FECHA_HORA, DESCRIPCION, CATEGORIA, PROVINCIA)
                VALUES (:ID_CREADOR, :AFORO, :NOMBRE, :FECHA_HORA, :DESCRIPCION, :CATEGORIA, :PROVINCIA)";
    
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":ID_CREADOR", $id_creador);
                $stmt->bindValue(":AFORO", $params["aforo"]);
                $stmt->bindValue(":NOMBRE", $params["nombre"]);
                $stmt->bindValue(":FECHA_HORA", $params["fecha"]);
                $stmt->bindValue(":DESCRIPCION", $params["descripcion"]);
                $stmt->bindValue(":CATEGORIA", $params["categoria"]);
                $stmt->bindValue(":PROVINCIA", $params["provincia"]);
                $stmt->execute();
    
                $this->guardarImagen($files);
                
                return true;
            }
            else {
                return false;
            }
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> BORRAR EVENTO
    function borrarEvento($id_evento) {
        try {
            // Recuperar nombre de imagen (si hay)
            $sql = "SELECT IMAGEN_EVENTO FROM eventos WHERE ID_EVENTO = :ID_EVENTO";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':ID_EVENTO', $id_evento);
            $stmt->execute();

            // Borrar imagen del directorio de imágenes
            $nombreImagen = $stmt->fetch()["IMAGEN_EVENTO"];
            $this->borrarImagen($nombreImagen);

            $sql = "DELETE FROM EVENTOS WHERE ID_EVENTO = :ID_EVENTO";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':ID_EVENTO', $id_evento);
            $stmt->execute();

            return true;
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> EDITAR EVENTO
    function modificarEvento($params, $files, $id_evento) {
        try {
            // Validar fecha
            $fecha_OK = strtotime($params["fecha"]) >= strtotime(date('Y-m-d'));

            // Validar aforo
            $sql = "SELECT eventos.AFORO, COUNT(subscripciones.ID_PERSONA) AS GENTE
            FROM eventos
            LEFT JOIN subscripciones ON eventos.ID_EVENTO = subscripciones.ID_EVENTO
            WHERE eventos.ID_EVENTO = :ID_EVENTO
            GROUP BY eventos.AFORO";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->execute();
            $gente = $stmt->fetch()["GENTE"];

            $params["aforo"] = $params["aforo"] >= 1 ? $params["aforo"] : 1;
            $aforo_OK = false;
            if (isset($params["aforo"])) {
                $aforo_OK = $params["aforo"] >= $gente ? true : false;
            }

            // Consulta
            if ($fecha_OK and $aforo_OK) {
                if (strlen($files['name'][0]) > 0) {
                    // Recuperar nombre de imagen (si hay)
                    $sql = "SELECT IMAGEN_EVENTO FROM eventos WHERE ID_EVENTO = :ID_EVENTO";
                    $stmt = $this->conn->prepare($sql);
                    $stmt->bindValue(':ID_EVENTO', $id_evento);
                    $stmt->execute();
    
                    // Actualizar imagen
                    $nombreImagen = $stmt->fetch()["IMAGEN_EVENTO"];
                    $this->borrarImagen($nombreImagen);
                    $this->guardarImagen($files, $id_evento);
                }
                
                // Actualizar registros
                $sql ="UPDATE eventos SET 
                    AFORO = :AFORO,
                    NOMBRE = :NOMBRE,
                    FECHA_HORA = :FECHA_HORA,
                    DESCRIPCION = :DESCRIPCION,
                    CATEGORIA = :CATEGORIA,
                    PROVINCIA = :PROVINCIA
                WHERE
                    ID_EVENTO = :ID_EVENTO";

                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":AFORO", $params["aforo"]);
                $stmt->bindValue(":NOMBRE", $params["nombre"]);
                $stmt->bindValue(":FECHA_HORA", $params["fecha"]);
                $stmt->bindValue(":DESCRIPCION", $params["descripcion"]);
                $stmt->bindValue(":CATEGORIA", $params["categoria"]);
                $stmt->bindValue(":PROVINCIA", $params["provincia"]);
                $stmt->bindValue(":ID_EVENTO", $id_evento);
                $stmt->execute();
    
                return true;
            }
            else {
                return false;
            }
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> MOSTRAR SUBSCRIPCIONES DEL USUARIO
    public function mostrarSubscripcionesUsuario($id_usuario) {
        try {
            $sql = "SELECT * FROM subscripciones WHERE ID_PERSONA = :ID_PERSONA";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_USUARIO", $id_usuario);
            $stmt->execute();
            $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $registros;
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> AGREGAR USUARIO A EVENTO
    public function agregarUsuarioEvento($id_evento, $id_usuario) {
        try {
            $datosEvento = $this->mostrarEvento($id_evento);

            // Antes de subscribir, comprobar que hay hueco
            if ($datosEvento["ID_EVENTO"] and $datosEvento["SUBSCRITOS"] < $datosEvento["AFORO"]) {
                $sql = "INSERT INTO subscripciones (ID_EVENTO, ID_PERSONA)
                VALUES (:ID_EVENTO, :ID_PERSONA)";

                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":ID_EVENTO", $id_evento);
                $stmt->bindValue(":ID_PERSONA", $id_usuario);
                $stmt->execute();
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> ELIMINAR USUARIO DE EVENTO
    public function eliminarUsuarioEvento($id_evento, $id_usuario) {
        try {
            $datosEvento = $this->mostrarEvento($id_evento);

            if ($datosEvento["ID_EVENTO"]) {
                $sql = "DELETE FROM subscripciones
                WHERE ID_EVENTO = :ID_EVENTO AND ID_PERSONA = :ID_PERSONA";
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":ID_EVENTO", $id_evento);
                $stmt->bindValue(":ID_PERSONA", $id_usuario);
                $stmt->execute();
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        } 
    }

    // >> OBTENER SI UN USUARIO SE HA UNIDO A UN EVENTO CONCRETO
    public function comporobarSubscripcion($id_evento, $id_usuario) {
        try {
            $sql = "SELECT * FROM subscripciones
            WHERE ID_EVENTO = :ID_EVENTO AND ID_PERSONA = :ID_PERSONA";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->bindValue(":ID_PERSONA", $id_usuario);
            $stmt->execute();
            $registros = $stmt->fetch();
    
            return $registros ? true : false;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }  
    }

    public function mostrarMensajes($id_evento) {
        try {
            $sql = "SELECT
                chat_evento.*,
                personas.NOMBRE AS NOMBRE_USUARIO,
                personas.APELLIDOS AS APELLIDOS_USUARIO
            FROM chat_evento
                LEFT JOIN personas ON chat_evento.ID_PERSONA = personas.ID_PERSONA
            WHERE ID_EVENTO = :ID_EVENTO";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->execute();
            $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        } 
    }

    public function insertarMensaje($id_evento, $id_usuario, $mensaje) {
        try {
            $sql = "INSERT INTO chat_evento (ID_EVENTO, ID_PERSONA, MENSAJE)
            VALUES (:ID_EVENTO, :ID_PERSONA, :MENSAJE)";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->bindValue(":ID_PERSONA", $id_usuario);
            $stmt->bindValue(":MENSAJE", $mensaje);
            $stmt->execute();
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        } 
    }

    public function borrarMensaje($mensaje) {
        try {
            $sql = "DELETE FROM chat_evento WHERE ID_MENSAJE = :ID_MENSAJE";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_MENSAJE", $mensaje);
            $stmt->execute();
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        } 
    }

    // ----------------------------------------------------------------------------------
    // >> Parte de reseñas
    public function mostrarResena($id_creador) {
        try {
            $sql = "SELECT
                resena.*,
                eventos.NOMBRE AS nombre_evento,
                personas.NOMBRE AS subscriptor
            FROM resena
                LEFT JOIN eventos ON resena.ID_EVENTO = eventos.ID_EVENTO
                LEFT JOIN personas On resena.ID_SUSCRIPTOR = personas.ID_PERSONA
            WHERE eventos.ID_CREADOR = :ID_CREADOR";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_CREADOR", $id_creador);
            $stmt->execute();
            $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $registros;
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> CALCULAR MEDIA PUNTUACION
    public function calcularMediaPuntuacion($id_persona) {
        try {
            $sql = "SELECT FLOOR(AVG(PUNTUACION)) AS TOTAL
            FROM resena
            LEFT JOIN eventos ON resena.ID_EVENTO = eventos.ID_EVENTO
            WHERE eventos.ID_CREADOR = :ID_PERSONA";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_PERSONA", $id_persona);
            $stmt->execute();
            $registros = $stmt->fetch();
            return $registros ? $registros["TOTAL"] : 0;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            return 0;
        }
    }

     // >> INGRESAR RESEÑA
     public function ingresarResena($params, $datosUsuario) {
        try {
            // Comprobamos si existe comentario en la reseña
            if(isset($params['comentario']) and !empty(trim($params['comentario']))){
                $sql = "INSERT INTO resena (COMENTARIO,PUNTUACION,ID_EVENTO, ID_SUSCRIPTOR)
                VALUES (:COMENTARIO, :PUNTUACION, :ID_EVENTO, :ID_SUSCRIPTOR)";

                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":COMENTARIO", $params['comentario']);
                $stmt->bindValue(":PUNTUACION", intval($params['puntuacion']));
                $stmt->bindValue(":ID_EVENTO", intval($params['id_evento']));
                $stmt->bindValue(":ID_SUSCRIPTOR", intval($datosUsuario));
                $stmt->execute();
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> MÉTODOS DE COMPROBACIÓN DE FECHAS
    #
    public function fechaLimiteResena($fechaEvento) {
        $fechaActual = new DateTime();              // Fecha actual
        $fechaActual->modify('-1 day');
        $fechaEvento = new DateTime($fechaEvento);  // Convertir la fecha de parámetro a objeto DateTime
        $fechaLimite = new DateTime();
        $fechaLimite->modify('-1 week');

        $fecha_OK = false;
        if ($fechaEvento >= $fechaLimite and $fechaEvento < $fechaActual) {
            $fecha_OK = true;
        }
        
        return $fecha_OK;
    }

    public function eventoExpirado($fechaEvento) {
        $fechaEvento = new DateTime($fechaEvento);  // Convertir la fecha de parámetro a objeto DateTime
        $fechaLimite = new DateTime();
        $fechaLimite->modify('-1 week');
        $fechaLimite->modify('-1 day');

        $fecha_EXPIRADA = false;
        if ($fechaEvento <= $fechaLimite) {
            $fecha_EXPIRADA = true;
        }
        
        return $fecha_EXPIRADA;
    }

    function verificarFechaResena($fechaEvento, $id_evento, $id_persona) {
        $fecha_OK = $this->fechaLimiteResena($fechaEvento);
       
        // Verificar si ya se ha hecho una reseña y si la fecha está dentro del rango permitido
        if ($fecha_OK) {
            $sql = "SELECT * FROM resena WHERE ID_EVENTO = :ID_EVENTO AND ID_SUSCRIPTOR = :ID_PERSONA";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->bindValue(":ID_PERSONA", $id_persona);
            $stmt->execute();
            $registros = $stmt->fetch();

            if (!$registros) {
                return false;
            }
        }

        // Si hay reseña
        return true;
    }

    //>> Comprobar si el usuario ya ha escrito una reseña
    function existeResenaUsuario($id_evento, $id_persona){
        try{
            $sql ="SELECT ID_RESENA FROM RESENA
            WHERE ID_EVENTO = :ID_EVENTO AND ID_SUSCRIPTOR = :ID_SUSCRIPTOR";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_EVENTO", $id_evento);
            $stmt->bindValue(":ID_SUSCRIPTOR",$id_persona);           
            $stmt->execute();
            $result = $stmt->fetch();
            return $result;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}